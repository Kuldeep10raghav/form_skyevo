<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class formcontroller extends Controller
{
    //
    function addDetails(Request $req)
    {
     return $req->input();
    }
}
