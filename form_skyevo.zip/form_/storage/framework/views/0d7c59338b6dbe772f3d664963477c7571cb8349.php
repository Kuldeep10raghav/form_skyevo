<?php echo $__env->make('theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h6 style="color: gray">*this form is only for submit the data & there has no interaction with DataBase.</h6>



  <h3 style="color:red;text-align: center"><b>Submit Form</b></h3>
<form method='post' action='submit' style="text-align: center">
    <?php echo csrf_field(); ?>
    <h6>Enter Your Name</h6>
   <input type="text" name="name" value="" placeholder="Enter Your Name" required>
   <br>
   <h6>Enter Your City</h6>

   <input type="text" name="city" value="" placeholder="City" required>
   <br>
   <h6>Enter Your State</h6>

   <input type="text" name="state" value="" placeholder="state" required>
   <br>
   <h6>Enter Your Contact No</h6>

   <input type="text" name="mobile" value="" placeholder="Mobile No." required>
   <br><br>
   <input type="submit" name="submit"  class="btn btn-success" value="SUBMIT">

  </form>

  
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
  
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
<?php /**PATH C:\Users\Raghav PC\Desktop\lrvl8\form_\resources\views/index.blade.php ENDPATH**/ ?>